#include <windows.h>
#include <shlobj.h>
#include <fstream>
#include <wincrypt.h>

#define IDR_PAYLOAD 1337
HWND hwnd, log_edit, log_btn;

bool extract(const char* outputPath) {
    HRSRC hRes = FindResource(NULL, MAKEINTRESOURCE(IDR_PAYLOAD), RT_RCDATA);
    if (!hRes) return false;

    HGLOBAL hData = LoadResource(NULL, hRes);
    if (!hData) return false;

    DWORD size = SizeofResource(NULL, hRes);
    void* pData = LockResource(hData);

    std::ofstream file(outputPath, std::ios::binary);
    file.write((char*)pData, size);
    file.close();

    return true;
}

void reg_write(const char* valueName, BYTE* data, DWORD len) {
    HKEY hKey;
    if (RegCreateKeyExA(HKEY_CURRENT_USER, "SOFTWARE\\Kubiuk", 0, NULL, 0, KEY_WRITE, NULL, &hKey, NULL) == ERROR_SUCCESS) {
        RegSetValueExA(hKey, valueName, 0, REG_BINARY, data, len);
        RegCloseKey(hKey);
    }
}

long WINAPI MainEventManager(HWND hw, UINT Code, WPARAM wParam, LPARAM lParam) {
    switch(Code) {
        case WM_CLOSE:
            DestroyWindow(hw);
            return 0;
        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
        case WM_COMMAND:
            if ((HWND)lParam == log_btn) {
                char p[128];
                GetWindowTextA(log_edit, p, sizeof(p));
                SetWindowTextA(log_edit, "");

                HCRYPTPROV hProv;
                if (!CryptAcquireContext(&hProv, NULL, NULL, PROV_RSA_FULL, CRYPT_VERIFYCONTEXT)) return 1;

                HCRYPTHASH hHash;
                if (!CryptCreateHash(hProv, CALG_SHA, 0, 0, &hHash)) {
                    CryptReleaseContext(hProv, 0);
                    return 1;
                }

                if (!CryptHashData(hHash, (BYTE*)p, (DWORD)strlen(p), 0)) {
                    CryptDestroyHash(hHash);
                    CryptReleaseContext(hProv, 0);
                    return 1;
                }

                BYTE hash[20];
                DWORD hash_len = 20;
                if (!CryptGetHashParam(hHash, HP_HASHVAL, hash, &hash_len, 0)) {
                    CryptDestroyHash(hHash);
                    CryptReleaseContext(hProv, 0);
                    return 1;
                }

                reg_write("key", hash, hash_len);

                CryptDestroyHash(hHash);
                CryptReleaseContext(hProv, 0);
                DestroyWindow(hw);
            }
            return 0;
    }
    return DefWindowProc(hw, Code, wParam, lParam);
}

HWND MainRegister(HINSTANCE Instance, char* Name, int x, int y, int w, int h) {
    static WNDCLASS rc;
    rc.lpfnWndProc = MainEventManager;
    rc.hInstance = Instance;
    rc.hIcon = LoadIcon(NULL, IDI_EXCLAMATION);
    rc.hCursor = LoadCursor(NULL, IDC_ARROW);
    rc.hbrBackground = CreateSolidBrush(RGB(255,255,255));
    rc.lpszClassName = Name;
    RegisterClass(&rc);
    return CreateWindow(Name, Name, WS_OVERLAPPEDWINDOW | WS_VISIBLE, x, y, w, h, NULL, NULL, Instance, NULL);
}

int WINAPI WinMain(HINSTANCE osInstance, HINSTANCE osPreviousInstance, LPSTR osParameters, int CommandShow) {
    BROWSEINFO bi = {0};
    bi.lpszTitle = "Choose a folder for installation";
    LPITEMIDLIST pidl = SHBrowseForFolder(&bi);

    if (pidl != 0) {
        char path[MAX_PATH];
        if (SHGetPathFromIDList(pidl, path)) {
            char result[MAX_PATH];
            snprintf(result, MAX_PATH, "%s\\lab1.exe", path);

            if (extract(result)) {
                MessageBox(NULL, "installed", "lab1", MB_OK | MB_ICONINFORMATION);
            } else {
                MessageBox(NULL, "error!", "fail", MB_OK | MB_ICONERROR);
            }
        }
        CoTaskMemFree(pidl);
    }

    char pc_name[MAX_COMPUTERNAME_LENGTH + 1];
    DWORD pc_size = sizeof(pc_name);
    GetComputerName(pc_name, &pc_size);

    char username[256];
    DWORD user_size = sizeof(username);
    GetUserName(username, &user_size);

    char sys_dir[MAX_PATH];
    GetSystemDirectory(sys_dir, MAX_PATH);

    char win_dir[MAX_PATH];
    GetWindowsDirectory(win_dir, MAX_PATH);

    int keyboard_type = GetKeyboardType(0);
    int keyboard_subtype = GetKeyboardType(1);

    int screen_width = GetSystemMetrics(SM_CXSCREEN);

    MEMORYSTATUSEX statex;
    statex.dwLength = sizeof(statex);
    GlobalMemoryStatusEx(&statex);

    char volume[MAX_PATH];
    GetVolumeInformation(NULL, volume, MAX_PATH, NULL, NULL, NULL, NULL, 0);

    char buffer[1024];
    snprintf(buffer, sizeof(buffer), "%s%s%s%s%d%d%d%llu%s", pc_name, username, sys_dir, win_dir, keyboard_type, keyboard_subtype, screen_width, statex.ullTotalPhys, volume);

    HCRYPTPROV hProv;
    if (!CryptAcquireContext(&hProv, "lab2", NULL, PROV_RSA_FULL, 0))
        if (!CryptAcquireContext(&hProv, "lab2", NULL, PROV_RSA_FULL, CRYPT_NEWKEYSET))
            return 1;

    HCRYPTKEY hKey;
    if (!CryptGetUserKey(hProv, AT_SIGNATURE, &hKey)) {
        if (!CryptGenKey(hProv, AT_SIGNATURE, 0, &hKey)) {
            CryptReleaseContext(hProv, 0);
            return 1;
        }
    }

    HCRYPTHASH hHash;
    if (!CryptCreateHash(hProv, CALG_SHA, 0, 0, &hHash)) {
        CryptReleaseContext(hProv, 0);
        return 1;
    }

    if (!CryptHashData(hHash, (BYTE*)buffer, (DWORD)strlen(buffer), 0)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return 1;
    }

    DWORD sig_len;
    CryptSignHash(hHash, AT_SIGNATURE, NULL, 0, NULL, &sig_len);
    BYTE* sig = (BYTE*)malloc(sig_len);

    if (!CryptSignHash(hHash, AT_SIGNATURE, NULL, 0, sig, &sig_len)) {
        free(sig);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv, 0);
        return 1;
    }

    reg_write("signature", sig, sig_len);
    
    free(sig);
    CryptDestroyHash(hHash);
    CryptDestroyKey(hKey);
    CryptReleaseContext(hProv, 0);

    hwnd = MainRegister(osInstance, "lab2", 50, 80, 440, 110);
    log_edit = CreateWindow("EDIT", "enter the passphrase for key", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 5, 20, 300, 25, hwnd, NULL, osInstance, NULL);
    log_btn = CreateWindow("BUTTON", "enter", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 330, 15, 70, 35, hwnd, NULL, osInstance, NULL);

    MSG msg;
    while (GetMessage(&msg, 0, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}