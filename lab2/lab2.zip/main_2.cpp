#include <windows.h>
#include <shlobj.h>
#include <fstream>
#include <wincrypt.h>

#define IDR_PAYLOAD 1337

bool extract(const char* outputPath) {
    HRSRC hRes = FindResource(NULL, MAKEINTRESOURCE(IDR_PAYLOAD), RT_RCDATA);
    if (!hRes) return false;

    HGLOBAL hData = LoadResource(NULL, hRes);
    if (!hData) return false;

    DWORD size = SizeofResource(NULL, hRes);
    void* pData = LockResource(hData);

    std::ofstream file(outputPath, std::ios::binary);
    file.write((char*)pData, size);
    file.close();

    return true;
}

int main() {
    BROWSEINFO bi = {0};
    bi.lpszTitle = "choose a folder for installation";
    LPITEMIDLIST pidl = SHBrowseForFolder(&bi);

    if (pidl != 0) {
        char path[MAX_PATH];
        if (SHGetPathFromIDList(pidl, path)) {
            char result[MAX_PATH];
            snprintf(result, MAX_PATH, "%s\\lab1.exe", path);

            if (extract(result)) MessageBox(NULL, "installed", "lab1", MB_OK | MB_ICONINFORMATION);
            else MessageBox(NULL, "error!", "fail", MB_OK | MB_ICONERROR);
        }
        CoTaskMemFree(pidl);
    }

    char pc_name[MAX_COMPUTERNAME_LENGTH + 1];
    DWORD pc_size = sizeof(pc_name);
    GetComputerName(pc_name, &pc_size);

    char username[256];
    DWORD user_size = sizeof(username);
    GetUserName(username, &user_size);

    char sys_dir[MAX_PATH];
    GetSystemDirectory(sys_dir, MAX_PATH);

    char win_dir[MAX_PATH];
    GetWindowsDirectory(win_dir, MAX_PATH);

    int keyboard_type = GetKeyboardType(0);
    int keyboard_subtype = GetKeyboardType(1);

    int screen_width = GetSystemMetrics(SM_CXSCREEN);

    MEMORYSTATUSEX statex;
    statex.dwLength = sizeof(statex);
    GlobalMemoryStatusEx(&statex);

    char volume[MAX_PATH];
    GetVolumeInformation(NULL, volume, MAX_PATH, NULL, NULL, NULL, NULL, 0);

    char buffer[1024];
    sprintf(buffer, "%s%s%s%s%d%d%d%llu%s", pc_name, username, sys_dir, win_dir, keyboard_type, keyboard_subtype, screen_width, statex.ullTotalPhys, volume);

    HCRYPTPROV hProv;
    if (!CryptAcquireContext(&hProv, "lab2", NULL, PROV_RSA_FULL, 0))
        if (!CryptAcquireContext(&hProv, "lab2", NULL, PROV_RSA_FULL, CRYPT_NEWKEYSET))
            return 1;

    HCRYPTKEY hKey;
    if (!CryptGetUserKey(hProv, AT_SIGNATURE, &hKey)) {
        if (!CryptGenKey(hProv, AT_SIGNATURE, 0, &hKey)) {
            CryptReleaseContext(hProv, 0);
            return 1;
        }
    }

    HCRYPTHASH hHash;
    if (!CryptCreateHash(hProv, CALG_SHA, 0, 0, &hHash)) {
        CryptReleaseContext(hProv,0);
        return 1;
    }

    if (!CryptHashData(hHash, (BYTE*)buffer, (DWORD)strlen(buffer), 0)) {
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv,0);
        return 1;
    }

    DWORD sig_len;
    CryptSignHash(hHash, AT_SIGNATURE, NULL, 0, NULL, &sig_len);
    BYTE* sig = (BYTE*)malloc(sig_len);

    if (!CryptSignHash(hHash, AT_SIGNATURE, NULL, 0, sig, &sig_len)) {
        free(sig);
        CryptDestroyHash(hHash);
        CryptReleaseContext(hProv,0);
        return 1;
    }

    HKEY hKeyReg;
    if (RegCreateKeyEx(HKEY_CURRENT_USER, "SOFTWARE\\Kubiuk", 0, NULL, 0, KEY_WRITE, NULL, &hKeyReg, NULL) == ERROR_SUCCESS) {
        RegSetValueEx(hKeyReg, "signature", 0, REG_BINARY, sig, sig_len);
        RegCloseKey(hKeyReg);
    }

    free(sig);
    CryptDestroyHash(hHash);
    CryptDestroyKey(hKey);
    CryptReleaseContext(hProv, 0);

    return 0;
}